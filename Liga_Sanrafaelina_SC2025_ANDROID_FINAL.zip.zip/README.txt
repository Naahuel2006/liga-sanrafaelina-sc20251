DATA PACK – LIGA SANRAFAELINA DE FÚTBOL
SOCCER CHAMPS 2025 ANDROID

Incluye:
- Liga Sanrafaelina completa
- Club La Llave priorizado
- Jugadores reales confirmados
- Ascensos reales hasta Primera Nacional

Instalación:
Android/data/com.monkeyibrow.soccerchamps/files/datapacks
